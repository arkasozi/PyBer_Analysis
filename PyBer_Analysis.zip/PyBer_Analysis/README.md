# PyBer_Analysis
Creating a summary of the ride share data by city type

We analysed the ride share data and noted that their are fewer drivers in the rural areas as compared to the urban ares and the clients are fewer. The amount of money made by the urban drivers
is alot more than the drivers in thr rural areas, and the fares charged by the drivers in the rural areas is moch lower compared ton the drivers in the urban areas.
While the fares in the ruarl areas are fairly constant, we notice a slight increase in the fares in march for the urban and suburban areas in the perriod of march 
the urban drivers have a higher ride average and it would be good to increase the drivers in the urban area to increase the fares and the profit margin
it would be good to also increase the drivers in the rural areas as this could be an untapped market and would increase the profits of the company, it would also be a good challenge to analyse the rural data more to determine how to increase the drivers and maximise the sales and clients in the area


It was a good challenge, I would like to get better analysis of the rural areas as this looks like untapped market and find ways to maximise sales and profits and build the company profile 
The Urban areas have a greater profit and have a higher number of drivers his the average fare per driver is slightly higher
